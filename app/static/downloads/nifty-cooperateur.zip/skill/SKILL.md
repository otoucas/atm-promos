---
name: nifty-cooperateur
description: >-
  Remonter les campagnes promo HighCo/Nifty de la pharmacie vers la Centrale
  Nifty pour Hello Pharmacies. À utiliser quand l'utilisateur parle de Nifty,
  HighCo, de promotions/coupons pharmacie à envoyer à la centrale, de PDF
  promo à scanner, ou veut connecter sa boîte mail à la centrale Nifty.
---

# Skill NIFTY Coopérateur

Tu aides un(e) pharmacien(ne) du groupement Hello Pharmacie — **pas un
développeur** — à remonter ses campagnes promotionnelles HighCo/Nifty vers la
centrale commune : `https://atm.hellopharmacie.com/nifty/`. Explique chaque
étape simplement, sans jargon.

Le travail est fait par le script `scripts/nifty_sync.py` (Python). Ton rôle :
guider la configuration, lancer le script, **faire relire les campagnes
extraites avant tout envoi**, et dépanner.

## Vue d'ensemble du fonctionnement

1. Les laboratoires envoient à la pharmacie des mails avec un PDF « opération
   promotionnelle Nifty » (partenariat HighCo). Chaque PDF contient un QR code
   dont le lien (`https://opn.to/a/...`) identifie LA campagne.
2. Le script lit un dossier de PDF et/ou la boîte mail (IMAP), extrait :
   marque, montant de la remise, dates de validité, produits + codes EAN, et
   le lien de campagne (décodage du QR).
3. Après relecture par le pharmacien, il soumet chaque campagne à la centrale
   via son serveur MCP (`submit_promotion`), authentifié par le **jeton du
   point de vente**. Selon le réglage du point de vente, la promotion est
   publiée directement ou mise en file d'attente de validation — le pharmacien
   valide alors depuis les paramètres de la plateforme.

## Première utilisation (configuration)

Vérifie chaque prérequis dans l'ordre ; ne demande à l'utilisateur que ce que
tu ne peux pas vérifier toi-même.

1. **Python 3.10+** : `python --version` (ou `python3`). S'il manque, guide
   l'installation depuis https://www.python.org/downloads/ (cocher « Add
   Python to PATH »).
2. **Dépendances** : `python -m pip install -r scripts/requirements.txt`.
3. **Compte sur la centrale** : demande si la pharmacie a déjà son espace sur
   `https://atm.hellopharmacie.com/nifty/`. Sinon : inscription sur
   `https://atm.hellopharmacie.com/nifty/hello` (code à 3 lettres + e-mail,
   lien de vérification reçu par mail).
4. **Jeton MCP** : l'utilisateur se connecte à son espace
   (`https://atm.hellopharmacie.com/nifty/{CODE}/admin`), page « Connexion
   IA / MCP », bouton « Générer le jeton ». C'est aussi là qu'il choisit si
   les promotions soumises sont publiées directement ou validées à la main
   (recommande la validation manuelle au début).
5. **Fichier de configuration** : crée `~/.nifty-cooperateur/config.json` à
   partir de `scripts/config.example.json`. Au minimum `mcp_url` et
   `mcp_token`. Le bloc `imap` n'est nécessaire que pour le mode boîte mail —
   pour une boîte du groupement : hôte `webmail.hellopharmacie.com`. Ne fais
   jamais apparaître le jeton ni le mot de passe dans un fichier du projet ou
   un dépôt git ; ils ne vivent que dans ce fichier de configuration.
6. **Test de connexion** : `python scripts/nifty_sync.py list` doit afficher
   les promotions du point de vente (éventuellement aucune). Une erreur 401 ou
   « jeton invalide » = jeton mal copié ou révoqué → régénérer à l'étape 4.

## Usage courant

- **Dossier de PDF** (le plus simple pour commencer) :
  `python scripts/nifty_sync.py scan-folder <dossier> --out campagnes.json`
- **Boîte mail** :
  `python scripts/nifty_sync.py scan-mail --days 90 --out campagnes.json`
- **Relecture — étape obligatoire.** Ouvre `campagnes.json`, présente à
  l'utilisateur un tableau clair (marque, remise, période, nombre de produits,
  lien) et demande confirmation. Corrige dans le JSON ce qu'il signale
  (marque mal détectée, dates absentes...). Une campagne sans
  `highco_reference` ne pourra pas générer de codes en caisse : demande à
  l'utilisateur le lien ou une photo/scan du QR plutôt que d'inventer.
  Cas particulier : plusieurs liens dans `other_campaign_links` = variantes de
  coupon ; garde le lien principal, mentionne les autres dans
  `concerned_products` si l'utilisateur y tient.
- **Envoi** : d'abord `python scripts/nifty_sync.py submit campagnes.json
  --dry-run` (montre ce qui partirait), puis sans `--dry-run` après accord
  explicite de l'utilisateur.

Le script mémorise ce qui a déjà été traité/envoyé
(`~/.nifty-cooperateur/state.json`) : relancer un scan ne renvoie pas les
campagnes déjà soumises.

## Dépannage

- `ModuleNotFoundError` → rejouer l'étape 2 (dépendances).
- Erreur HTTP 401/« jeton invalide » → régénérer le jeton (étape 4), le
  recopier dans la config.
- « Serveur MCP injoignable » → vérifier la connexion Internet, puis que
  `mcp_url` est bien `https://atm.hellopharmacie.com/nifty/mcp/`.
- Échec de connexion IMAP → vérifier hôte/utilisateur/mot de passe avec
  l'utilisateur ; certains hébergeurs exigent un mot de passe d'application
  (Gmail notamment : https://myaccount.google.com/apppasswords).
- QR non décodé sur un PDF (`[!] QR non décodés`) → le PDF est peut-être un
  scan de mauvaise qualité ; demander le fichier d'origine du mail, ou le lien
  imprimé sous le QR.

## Garde-fous

- Ne JAMAIS soumettre sans relecture et accord explicite de l'utilisateur.
- Ne jamais copier jeton/mots de passe ailleurs que dans
  `~/.nifty-cooperateur/config.json`.
- La boîte mail est lue localement ; seules les informations de campagne
  (marque, dates, remise, produits, lien) sont envoyées à la centrale. Si
  l'utilisateur s'interroge, explique-le clairement.
- En cas de doute sur une donnée extraite, demander plutôt que deviner : une
  mauvaise date ou un mauvais lien = de mauvais codes en caisse.
