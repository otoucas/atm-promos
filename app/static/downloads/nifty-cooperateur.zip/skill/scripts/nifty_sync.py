#!/usr/bin/env python3
"""nifty_sync — remonte les campagnes promo HighCo/Nifty d'une pharmacie
vers la Centrale Nifty pour Hello Pharmacies (https://atm.hellopharmacie.com/nifty/).

Sources : un dossier de PDF NIFTY, et/ou une boîte mail en IMAP.
Sortie : un fichier campagnes.json (à relire), puis soumission au serveur MCP
de la centrale (outil submit_promotion), authentifiée par le jeton du point
de vente (généré dans /{code}/admin/mcp sur la plateforme).

Commandes :
  python nifty_sync.py scan-folder <dossier> [--out campagnes.json]
  python nifty_sync.py scan-mail [--days 90] [--out campagnes.json]
  python nifty_sync.py list                     # promotions déjà connues de la centrale
  python nifty_sync.py submit <campagnes.json> [--dry-run]

Configuration : %USERPROFILE%/.nifty-cooperateur/config.json (voir config.example.json).
Ce script n'envoie RIEN sans passer par `submit`, et `--dry-run` montre tout sans envoyer.
"""

import argparse
import hashlib
import imaplib
import email
import email.utils
from email.header import decode_header, make_header
import io
import json
import re
import sys
import urllib.request
import urllib.error
from datetime import date, datetime, timedelta
from pathlib import Path

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")

CONFIG_DIR = Path.home() / ".nifty-cooperateur"
CONFIG_FILE = CONFIG_DIR / "config.json"
STATE_FILE = CONFIG_DIR / "state.json"

# Liens présents dans tous les courriers HighCo, sans valeur pour identifier
# UNE campagne — jamais retenus comme référence.
GENERIC_LINK_PATTERNS = ("nifty.highco.com", "gestion-promo.fr", "highco-data.fr", "apple.com", "google.com")

# ---------------------------------------------------------------- config/état


def load_config() -> dict:
    if not CONFIG_FILE.exists():
        sys.exit(
            f"Configuration absente : {CONFIG_FILE}\n"
            "Copiez config.example.json à cet emplacement et renseignez au minimum "
            "mcp_url et mcp_token (jeton généré dans les réglages de votre point de "
            "vente sur la centrale, page « Connexion IA / MCP »)."
        )
    return json.loads(CONFIG_FILE.read_text(encoding="utf-8"))


def load_state() -> dict:
    if STATE_FILE.exists():
        return json.loads(STATE_FILE.read_text(encoding="utf-8"))
    return {"processed_files": {}, "processed_message_ids": [], "submitted_references": []}


def save_state(state: dict) -> None:
    CONFIG_DIR.mkdir(exist_ok=True)
    STATE_FILE.write_text(json.dumps(state, ensure_ascii=False, indent=2), encoding="utf-8")


# ---------------------------------------------------------------- extraction

_MONTHS_FR = {
    "janvier": 1, "février": 2, "fevrier": 2, "mars": 3, "avril": 4, "mai": 5,
    "juin": 6, "juillet": 7, "août": 8, "aout": 8, "septembre": 9,
    "octobre": 10, "novembre": 11, "décembre": 12, "decembre": 12,
}
_MONTH_PAT = "|".join(_MONTHS_FR)

# « du 01/05/2026 au 31/07/2026 », « du 01/07/26 au 30/09/26 », « du 01/06 au 31/07/26 »
_NUM_RANGE = re.compile(
    r"du\s+(\d{1,2})(?:\s*/\s*(\d{1,2}))?(?:\s*/\s*(\d{2,4}))?\s+(?:jusqu.au|au)\s+"
    r"(\d{1,2})\s*/\s*(\d{1,2})\s*/\s*(\d{2,4})",
    re.IGNORECASE,
)
# « du 1er mai au 31 juillet 2026 », « OFFRE VALABLE DU 1ER MAI AU 31 JUILLET 2026 »
_TXT_RANGE = re.compile(
    r"du\s+(\d{1,2})(?:er)?\s*(?:(" + _MONTH_PAT + r")\s*)?(?:(\d{4})\s+)?(?:jusqu.au|au)\s+"
    r"(\d{1,2})(?:er)?\s+(" + _MONTH_PAT + r")\s+(\d{4})",
    re.IGNORECASE,
)

_DISCOUNT = re.compile(
    r"(?:remise|réduction|reduction)[^.\n]{0,40}?(?:de\s+)?[-–]?\s*(\d+(?:[.,]\d+)?)\s*(€|euros?|%)"
    r"|[-–]?\s*(\d+(?:[.,]\d+)?)\s*(€|euros?|%)\s*(?:de\s+)?(?:remise|réduction|reduction)",
    re.IGNORECASE,
)

_EAN_LINE = re.compile(r"^(\d{13})\s+(.{3,120})$", re.MULTILINE)

# « Les Laboratoires Forté Pharma vous proposent », « FIXODENT, vous propose »,
# « GUM® SONIC, vous propose », « Le laboratoire Perrigo, vous propose »
_BRAND_SENTENCE = re.compile(
    r"(?:les?\s+laboratoires?\s+)?([A-Z0-9][^\n,]{2,60}?),?\s+vous\s+propose",
    re.IGNORECASE,
)

_URL = re.compile(r"https?://[^\s<>\")\]]+")


def _year4(y: int) -> int:
    return y + 2000 if y < 100 else y


def extract_dates(text: str):
    m = _NUM_RANGE.search(text)
    if m:
        d1, m1, y1, d2, m2, y2 = m.groups()
        end = date(_year4(int(y2)), int(m2), int(d2))
        start_month = int(m1) if m1 else end.month
        start_year = _year4(int(y1)) if y1 else end.year
        try:
            return date(start_year, start_month, int(d1)), end
        except ValueError:
            return None, end
    m = _TXT_RANGE.search(text)
    if m:
        d1, month1, y1, d2, month2, y2 = m.groups()
        end = date(int(y2), _MONTHS_FR[month2.lower()], int(d2))
        start_month = _MONTHS_FR[month1.lower()] if month1 else end.month
        start_year = int(y1) if y1 else end.year
        try:
            return date(start_year, start_month, int(d1)), end
        except ValueError:
            return None, end
    return None, None


def extract_discount(text: str) -> str:
    m = _DISCOUNT.search(text)
    if not m:
        return ""
    amount = m.group(1) or m.group(3)
    unit = m.group(2) or m.group(4)
    unit = "€" if unit.lower().startswith(("€", "e")) else "%"
    return f"{amount.replace('.', ',')}{unit}"


def extract_brand(text: str, fallback: str = "") -> str:
    m = _BRAND_SENTENCE.search(text)
    if m:
        brand = m.group(1).strip(" .®™*")
        # la phrase capture parfois une fin de ligne précédente — garder court
        if 2 < len(brand) <= 60:
            return brand
    return fallback


def brand_from_filename(path_name: str) -> str:
    stem = Path(path_name).stem
    stem = re.sub(r"^PJ[_ -]*", "", stem, flags=re.IGNORECASE)
    stem = re.sub(r"[_ -]*(DEF|PROLONGATION|V\d+|BAT)[_ -]*$", "", stem, flags=re.IGNORECASE)
    return stem.replace("_", " ").strip().title()


def extract_products(text: str):
    """Retourne (noms, eans) depuis le tableau « LISTE DES RÉFÉRENCES ÉLIGIBLES »."""
    names, eans = [], []
    for ean, label in _EAN_LINE.findall(text):
        eans.append(ean)
        names.append(label.strip())
    return names, eans


def decode_qr_links(pdf_bytes: bytes) -> list:
    """Rend chaque page et décode les QR codes (OpenCV, sans dépendance système)."""
    import pypdfium2 as pdfium
    import cv2
    import numpy as np

    links, seen = [], set()
    detector = cv2.QRCodeDetector()
    pdf = pdfium.PdfDocument(io.BytesIO(pdf_bytes))
    try:
        for page in pdf:
            arr = np.asarray(page.render(scale=3.0).to_pil().convert("RGB"))[:, :, ::-1]
            ok, decoded, _, _ = detector.detectAndDecodeMulti(arr)
            if ok:
                for value in decoded:
                    value = (value or "").strip()
                    if value and value not in seen:
                        seen.add(value)
                        links.append(value)
    finally:
        pdf.close()
    return links


def pdf_text_and_annot_links(pdf_bytes: bytes):
    import pdfplumber
    import pypdf

    text_parts, links = [], []
    with pdfplumber.open(io.BytesIO(pdf_bytes)) as pdf:
        for page in pdf.pages:
            text_parts.append(page.extract_text() or "")
    reader = pypdf.PdfReader(io.BytesIO(pdf_bytes))
    for page in reader.pages:
        for annot in page.get("/Annots") or []:
            obj = annot.get_object()
            action = obj.get("/A")
            uri = action.get("/URI") if action else None
            if uri:
                links.append(str(uri))
    return "\n".join(text_parts), links


def is_generic_link(url: str) -> bool:
    return any(pat in url for pat in GENERIC_LINK_PATTERNS)


def pick_reference(qr_links: list, other_links: list, text: str):
    """La référence HighCo = le lien de la campagne. Priorité aux QR décodés
    (liens opn.to), puis aux liens cliquables/texte non génériques."""
    candidates = [u for u in qr_links if u.startswith("http") and not is_generic_link(u)]
    if candidates:
        return candidates[0], candidates[1:]
    fallback = [u for u in other_links + _URL.findall(text) if not is_generic_link(u)]
    return (fallback[0], fallback[1:]) if fallback else (None, [])


def analyze_pdf(pdf_bytes: bytes, origin: str) -> dict:
    text, annot_links = pdf_text_and_annot_links(pdf_bytes)
    try:
        qr_links = decode_qr_links(pdf_bytes)
    except Exception as exc:  # décodage QR = meilleur effort, jamais bloquant
        print(f"  [!] QR non décodés ({origin}) : {exc}", file=sys.stderr)
        qr_links = []
    reference, extra_refs = pick_reference(qr_links, annot_links, text)
    valid_from, valid_until = extract_dates(text)
    names, eans = extract_products(text)
    return {
        "brand_name": extract_brand(text, fallback=brand_from_filename(origin)),
        "operation_label": extract_discount(text),
        "valid_from": valid_from.isoformat() if valid_from else "",
        "valid_until": valid_until.isoformat() if valid_until else "",
        "concerned_products": ", ".join(names),
        "highco_reference": reference or "",
        "ean_codes": eans,
        "other_campaign_links": extra_refs,
        "origin": origin,
    }


# ---------------------------------------------------------------- sources


def scan_folder(folder: Path, state: dict) -> list:
    campaigns = []
    pdfs = sorted({p for p in folder.rglob("*") if p.suffix.lower() == ".pdf"})
    if not pdfs:
        print(f"Aucun PDF dans {folder}")
    for pdf_path in pdfs:
        data = pdf_path.read_bytes()
        digest = hashlib.sha256(data).hexdigest()
        if digest in state["processed_files"]:
            print(f"  déjà traité : {pdf_path.name}")
            continue
        print(f"  analyse : {pdf_path.name}")
        campaign = analyze_pdf(data, pdf_path.name)
        campaign["sha256"] = digest
        campaigns.append(campaign)
    return campaigns


def _decode_hdr(raw: str) -> str:
    try:
        return str(make_header(decode_header(raw or "")))
    except Exception:
        return raw or ""


def scan_mail(cfg: dict, days: int, state: dict) -> list:
    imap_cfg = cfg.get("imap") or {}
    for key in ("host", "user", "password"):
        if not imap_cfg.get(key):
            sys.exit(f"Configuration IMAP incomplète : champ « {key} » manquant dans {CONFIG_FILE}")

    conn = imaplib.IMAP4_SSL(imap_cfg["host"], int(imap_cfg.get("port", 993)))
    conn.login(imap_cfg["user"], imap_cfg["password"])
    conn.select(imap_cfg.get("mailbox", "INBOX"))

    since = (datetime.now() - timedelta(days=days)).strftime("%d-%b-%Y")
    senders = imap_cfg.get("senders") or ["highco-data.fr", "gestion-promo.fr"]
    criteria = f'FROM "{senders[0]}"'
    for sender in senders[1:]:
        criteria = f'OR ({criteria}) (FROM "{sender}")'
    status, data = conn.uid("SEARCH", None, f"(SINCE {since}) ({criteria})")
    uids = data[0].split() if status == "OK" else []

    # Repli contenu : mails récents dont l'objet évoque une promo Nifty,
    # quel que soit l'expéditeur (labos qui envoient en direct).
    status, data2 = conn.uid("SEARCH", None, f'(SINCE {since}) (OR (SUBJECT "NIFTY") (SUBJECT "PROMO"))')
    if status == "OK":
        uids = list(dict.fromkeys(uids + data2[0].split()))

    print(f"{len(uids)} mail(s) candidats depuis {days} jours")
    campaigns = []
    for uid in uids:
        status, msg_data = conn.uid("FETCH", uid, "(RFC822)")
        if status != "OK" or not msg_data or msg_data[0] is None:
            continue
        msg = email.message_from_bytes(msg_data[0][1])
        message_id = msg.get("Message-ID") or f"no-id-{uid.decode()}"
        if message_id in state["processed_message_ids"]:
            continue
        subject = _decode_hdr(msg.get("Subject", ""))
        found_in_mail = 0
        for part in msg.walk():
            filename = _decode_hdr(part.get_filename() or "")
            payload = part.get_payload(decode=True) if filename else None
            if not payload:
                continue
            looks_pdf = filename.lower().endswith(".pdf") or payload[:4] == b"%PDF"
            if not looks_pdf:
                continue
            print(f"  analyse : {filename}  (mail : {subject[:60]})")
            campaign = analyze_pdf(payload, filename)
            campaign["mail_subject"] = subject
            campaign["mail_message_id"] = message_id
            campaigns.append(campaign)
            found_in_mail += 1
        if not found_in_mail:
            # pas de PDF : le corps contient peut-être directement le lien
            body = ""
            for part in msg.walk():
                if part.get_content_type() in ("text/plain", "text/html") and not part.get_filename():
                    try:
                        body += part.get_payload(decode=True).decode(part.get_content_charset() or "utf-8", "replace")
                    except Exception:
                        pass
            links = [u for u in _URL.findall(body) if not is_generic_link(u)]
            opn = [u for u in links if "opn.to" in u]
            if opn and ("nifty" in body.lower() or "nifty" in subject.lower() or "highco" in body.lower()):
                valid_from, valid_until = extract_dates(body)
                campaigns.append({
                    "brand_name": re.sub(r"^PROMO\s*\[?NIFTY\]?\s*", "", subject, flags=re.I).strip() or subject,
                    "operation_label": extract_discount(body) or extract_discount(subject),
                    "valid_from": valid_from.isoformat() if valid_from else "",
                    "valid_until": valid_until.isoformat() if valid_until else "",
                    "concerned_products": "",
                    "highco_reference": opn[0],
                    "ean_codes": [],
                    "other_campaign_links": opn[1:],
                    "origin": f"corps du mail : {subject[:80]}",
                    "mail_subject": subject,
                    "mail_message_id": message_id,
                })
    conn.logout()
    return campaigns


# ---------------------------------------------------------------- client MCP


def mcp_call(cfg: dict, tool: str, arguments: dict):
    """Appel d'un outil du serveur MCP de la centrale (streamable HTTP, mode
    stateless + réponses JSON). Authentification : Bearer <jeton du magasin>."""
    payload = {
        "jsonrpc": "2.0",
        "id": 1,
        "method": "tools/call",
        "params": {"name": tool, "arguments": arguments},
    }
    request = urllib.request.Request(
        cfg["mcp_url"],
        data=json.dumps(payload).encode("utf-8"),
        headers={
            "Content-Type": "application/json",
            "Accept": "application/json, text/event-stream",
            "Authorization": f"Bearer {cfg['mcp_token']}",
            "MCP-Protocol-Version": "2025-06-18",
        },
        method="POST",
    )
    try:
        with urllib.request.urlopen(request, timeout=60) as resp:
            body = resp.read().decode("utf-8", "replace")
    except urllib.error.HTTPError as exc:
        detail = exc.read().decode("utf-8", "replace")[:400]
        sys.exit(f"Erreur HTTP {exc.code} du serveur MCP : {detail}")
    except urllib.error.URLError as exc:
        sys.exit(f"Serveur MCP injoignable ({cfg['mcp_url']}) : {exc.reason}")

    # json_response=True → JSON direct ; sinon flux SSE « data: {...} »
    if body.lstrip().startswith("{"):
        message = json.loads(body)
    else:
        message = None
        for line in body.splitlines():
            if line.startswith("data:"):
                message = json.loads(line[5:].strip())
        if message is None:
            sys.exit(f"Réponse MCP illisible : {body[:300]}")

    if "error" in message:
        sys.exit(f"Erreur MCP : {message['error'].get('message', message['error'])}")
    result = message["result"]
    if result.get("isError"):
        texts = [c.get("text", "") for c in result.get("content", [])]
        sys.exit(f"L'outil {tool} a renvoyé une erreur : {' '.join(texts)[:400]}")
    if "structuredContent" in result:
        structured = result["structuredContent"]
        return structured.get("result", structured)
    for content in result.get("content", []):
        if content.get("type") == "text":
            try:
                return json.loads(content["text"])
            except (ValueError, KeyError):
                return content["text"]
    return result


# ---------------------------------------------------------------- commandes


def cmd_scan(campaigns: list, out_path: Path) -> None:
    with_ref = [c for c in campaigns if c["highco_reference"]]
    without_ref = [c for c in campaigns if not c["highco_reference"]]
    out_path.write_text(json.dumps(campaigns, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"\n{len(campaigns)} campagne(s) extraite(s) -> {out_path}")
    for c in with_ref:
        period = f"{c['valid_from'] or '?'} → {c['valid_until'] or '?'}"
        print(f"  ✓ {c['brand_name']:30} {c['operation_label']:>6}  {period}  {c['highco_reference']}")
    for c in without_ref:
        print(f"  ✗ {c['brand_name']:30} SANS lien de campagne ({c['origin']}) — à compléter à la main")
    if campaigns:
        print("\nRelisez/corrigez ce fichier puis lancez :")
        print(f"  python {Path(sys.argv[0]).name} submit {out_path}")


def cmd_submit(cfg: dict, state: dict, campaigns_path: Path, dry_run: bool) -> None:
    campaigns = json.loads(campaigns_path.read_text(encoding="utf-8"))
    existing = mcp_call(cfg, "list_promotions", {})
    known_refs = {p.get("id"): p for p in existing} if isinstance(existing, dict) else {}
    existing_list = existing if isinstance(existing, list) else []
    print(f"{len(existing_list)} promotion(s) déjà connues de la centrale pour votre point de vente")

    submitted = skipped = 0
    for c in campaigns:
        ref = (c.get("highco_reference") or "").strip()
        brand = (c.get("brand_name") or "").strip()
        if not ref or not brand:
            print(f"  ignorée (marque ou lien manquant) : {brand or c.get('origin')}")
            skipped += 1
            continue
        if ref in state["submitted_references"]:
            print(f"  déjà soumise précédemment : {brand}")
            skipped += 1
            continue
        # dédoublonnage distant : même lien déjà présent dans une promo existante
        duplicate = any(ref and ref in json.dumps(p, ensure_ascii=False) for p in existing_list)
        # NB : list_promotions n'expose pas highco_reference à ce jour — le
        # test ci-dessus couvre le cas où il serait ajouté ; en attendant on
        # compare aussi marque + période.
        if not duplicate:
            duplicate = any(
                (p.get("brand_name") or "").strip().lower() == brand.lower()
                and (p.get("valid_until") or "") == (c.get("valid_until") or "")
                for p in existing_list
            )
        if duplicate:
            print(f"  doublon centrale, non renvoyée : {brand}")
            skipped += 1
            continue

        products = (c.get("concerned_products") or "").strip()
        if dry_run:
            print(f"  [dry-run] {brand} | {c.get('operation_label')} | {c.get('valid_from')}→{c.get('valid_until')} | {ref}")
            continue
        result = mcp_call(cfg, "submit_promotion", {
            "brand_name": brand,
            "highco_reference": ref,
            "operation_label": c.get("operation_label") or "",
            "valid_from": c.get("valid_from") or "",
            "valid_until": c.get("valid_until") or "",
            "concerned_products": products,
        })
        print(f"  envoyée : {brand} -> {result.get('message', result) if isinstance(result, dict) else result}")
        state["submitted_references"].append(ref)
        if c.get("sha256"):
            state["processed_files"][c["sha256"]] = {"origin": c.get("origin"), "date": date.today().isoformat()}
        if c.get("mail_message_id"):
            state["processed_message_ids"].append(c["mail_message_id"])
        submitted += 1

    if not dry_run:
        save_state(state)
    print(f"\n{submitted} envoyée(s), {skipped} ignorée(s).")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = parser.add_subparsers(dest="command", required=True)

    p_folder = sub.add_parser("scan-folder", help="analyser un dossier de PDF NIFTY")
    p_folder.add_argument("folder", type=Path)
    p_folder.add_argument("--out", type=Path, default=Path("campagnes.json"))

    p_mail = sub.add_parser("scan-mail", help="relever la boîte mail configurée (IMAP)")
    p_mail.add_argument("--days", type=int, default=90)
    p_mail.add_argument("--out", type=Path, default=Path("campagnes.json"))

    sub.add_parser("list", help="lister les promotions connues de la centrale")

    p_submit = sub.add_parser("submit", help="soumettre les campagnes d'un fichier JSON relu")
    p_submit.add_argument("campaigns", type=Path)
    p_submit.add_argument("--dry-run", action="store_true")

    args = parser.parse_args()
    state = load_state()

    if args.command == "scan-folder":
        cmd_scan(scan_folder(args.folder, state), args.out)
    elif args.command == "scan-mail":
        cfg = load_config()
        cmd_scan(scan_mail(cfg, args.days, state), args.out)
    elif args.command == "list":
        cfg = load_config()
        for p in mcp_call(cfg, "list_promotions", {}):
            print(f"  {p.get('status'):8} {p.get('brand_name'):30} {p.get('valid_from')}→{p.get('valid_until')}  ({p.get('source')})")
    elif args.command == "submit":
        cfg = load_config()
        cmd_submit(cfg, state, args.campaigns, args.dry_run)


if __name__ == "__main__":
    main()
